import { Injectable } from '@angular/core';
import { LoginCredentials } from '../model/login-credentials';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  correctCredentials: LoginCredentials;

  constructor() {
    // sets default correct credentials
    this.correctCredentials = new LoginCredentials();
    this.correctCredentials.email = 'admin@gmail.com';
    this.correctCredentials.password = '123456';
  }
}
