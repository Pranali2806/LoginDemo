import { LoginCredentials } from './login-credentials';

describe('LoginCredentials', () => {
  it('should create an instance', () => {
    expect(new LoginCredentials()).toBeTruthy();
  });
});
