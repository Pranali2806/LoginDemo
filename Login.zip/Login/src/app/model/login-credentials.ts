export class LoginCredentials {
    email: String;
    password: String;

}
